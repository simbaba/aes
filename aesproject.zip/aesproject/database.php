<?php
$cn=mysql_connect("localhost","root","simeon") or die("Could not Connect My Sql");
mysql_select_db("exam",$cn)  or die("Could connect to Database");
?>
